(*
 * File: mp6-skeleton.ml
 *)

open Mp6common

(* Problem 0*)
let asMonoTy1 () = failwith "Not implemented"
let asMonoTy2 () = failwith "Not implemented"
let asMonoTy3 () = failwith "Not implemented"
let asMonoTy4 () = failwith "Not implemented"

(* Problem 1*)
let rec subst_fun subst m = failwith "Not implemented"

(* Problem 2*)
let rec monoTy_lift_subst subst monoTy = failwith "Not implemented"

(* Problem 3*)
let rec occurs x ty = failwith "Not implemented"

(* Problem 4*)
let rec unify eqlst = failwith "Not implemented"

(* Problem 5: No Credit *)
let equiv_types ty1 ty2 = failwith "Not implemented"
