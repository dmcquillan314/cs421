(* CS421 - Summer 2015
 * MP1
 *
 * Please keep in mind that there may be more than one
 * way to solve a problem.  You will want to change how a number of these start.
 *)

open Mp1common

(* Problem 1 *)
let title = "" (* Change this *)

(* Problem 2 *)
let e = 0.0  (* Change this *)

(* Problem 3 *)
let firstFun n = raise (Failure "Function not implemented yet.")

(* Problem 4 *)
let divide_e_by x = raise (Failure "Function not implemented yet.")

(* Problem 5 *)
let diff_square_9 m = raise (Failure "Function not implemented yet.")

(* Problem 6 *)
let dist_double s n = raise (Failure "Function not implemented yet.")

(* Problem 7 *)
let swizzle (w,x,y,z) = raise (Failure "Function not implemented yet.")

